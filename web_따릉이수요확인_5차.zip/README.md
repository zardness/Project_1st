# 따릉이 수요확인
- VS Code 확장 "Live Server" 설치 → index.html 우클릭 → Open with Live Server
- 데이터 입력 위치: js/data.js (STATION_DATA, DISTRICT_SUMMARY)
