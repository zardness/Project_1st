const name = new URLSearchParams(location.search).get("name");
if (!DISTRICTS.some(d => d.name === name)) location.href = "index.html";

document.getElementById("districtTitle").textContent = name + " 따릉이 수요확인";
const stations = STATION_DATA[name] || [];
const listEl = document.getElementById("stationList");
const dateEl = document.getElementById("dateSelect");
const slotEl = document.getElementById("slotSelect");

/* ---------- 날짜 / 시간대 선택 ---------- */
const pad = n => String(n).padStart(2, "0");
// 현재 날짜 (toISOString 은 UTC 라 날짜가 하루 어긋날 수 있어 로컬 시간으로 직접 만듭니다)
const todayStr = () => { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; };

// 1시간 단위 시간대: 00시~01시 ... 23시~24시 (value = 시작 시각 0~23)
for (let h = 0; h < 24; h++) {
  const o = document.createElement("option");
  o.value = h;
  o.textContent = `${pad(h)}시~${pad(h + 1)}시`;
  slotEl.appendChild(o);
}

function setToNow() {                 // 날짜 = 오늘, 시간대 = 현재 시각이 속한 시간대
  dateEl.value = todayStr();
  slotEl.value = new Date().getHours();
}
setToNow();                           // 처음 들어오면 현재 날짜/시간대가 선택된 상태
// 날짜 선택 범위를 제한하려면: dateEl.min = "2026-01-01"; dateEl.max = "2026-12-31";

const getSelection = () => ({ date: dateEl.value, hour: Number(slotEl.value) });
const selectionLabel = ({ date, hour }) => {
  const [y, m, d] = date.split("-").map(Number);
  const wd = new Date(y, m - 1, d).toLocaleDateString("ko-KR", { weekday: "short" });
  return `${date} (${wd}) ${pad(hour)}시~${pad(hour + 1)}시`;
};

/* ---------- 데이터 조회 (데이터 넣는 곳: js/data.js) ---------- */
// 선택한 날짜/시간대의 대여소 예측값. 데이터가 없으면 null
const getPrediction = (st, { date, hour }) => st.predicted?.[date]?.[hour] ?? null;
// 선택한 날짜/시간대의 자치구 요약. 데이터가 없으면 null
const getSummary = ({ date, hour }) => DISTRICT_SUMMARY[name]?.[date]?.[hour] ?? null;

/* ---------- 화면 그리기 ---------- */
let currentStation = null;

function renderSummary() {
  const sel = getSelection(), s = getSummary(sel);
  document.getElementById("summary").innerHTML = `<h2>${name} 요약</h2>
    <p class="sel-label">${selectionLabel(sel)} 기준</p>` + (s
    ? `<p>대여소 ${s.stationCount}곳 · 예상 총 대여량 ${s.totalPredicted}</p>`
    : `<div class="placeholder-box">
         <!-- [데이터 넣는 곳] getSummary(sel) 결과(총 예측 대여량 등)를 표시하는 영역 -->
         선택한 날짜/시간대의 자치구 수요 요약이 들어갈 자리</div>`);
}

function renderList() {
  const sel = getSelection();
  const q = document.getElementById("search").value;
  const items = stations.filter(st => st.name.includes(q));
  listEl.innerHTML = items.length ? "" : `<div class="empty">표시할 대여소 데이터가 없습니다.</div>`;
  items.forEach(st => {
    const p = getPrediction(st, sel);
    const card = document.createElement("div");
    card.className = "station-card";
    card.innerHTML = `<div class="st-name"></div><div class="st-demand">${p === null ? "예측 수요: -" : "예측 수요: " + p}</div>`;
    card.querySelector(".st-name").textContent = st.name;
    card.onclick = () => openDetail(st);
    listEl.appendChild(card);
  });
}

function renderDetail() {
  if (!currentStation) return;
  const sel = getSelection(), p = getPrediction(currentStation, sel);
  document.getElementById("detailName").textContent = currentStation.name;
  document.getElementById("detailBody").innerHTML = `
    <p class="sel-label">${selectionLabel(sel)} 기준</p>
    <p>예측 수요: <strong>${p === null ? "-" : p}</strong></p>
    <div class="placeholder-box">
      <!-- [데이터 넣는 곳] currentStation.predicted[선택날짜] 로 시간대별 수요예측 그래프(Chart.js 등) 그리기 -->
      수요예측 그래프 영역
    </div>`;
}

function openDetail(st) {
  currentStation = st;
  renderDetail();
  document.getElementById("detail").classList.remove("hidden");
}

// 날짜/시간대가 바뀔 때마다 전체 갱신
function refresh() { renderSummary(); renderList(); renderDetail(); }

dateEl.addEventListener("change", () => { if (!dateEl.value) dateEl.value = todayStr(); refresh(); });
slotEl.addEventListener("change", refresh);
document.getElementById("nowBtn").onclick = () => { setToNow(); refresh(); };
document.getElementById("search").oninput = renderList;
document.getElementById("closeDetail").onclick = () => {
  currentStation = null;
  document.getElementById("detail").classList.add("hidden");
};

refresh();
