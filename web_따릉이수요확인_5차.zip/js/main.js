const NS = "http://www.w3.org/2000/svg";
const XLINK = "http://www.w3.org/1999/xlink";
const LINES_SRC  = "images/seoul_lines.png";   // 경계선만
const LABELS_SRC = "images/seoul_labels.png";  // 자치구 이름만
const popLayer = document.getElementById("popLayer");
const hitLayer = document.getElementById("hitLayer");
const VB = `0 0 ${MAP_SIZE.w} ${MAP_SIZE.h}`;
popLayer.setAttribute("viewBox", VB);
hitLayer.setAttribute("viewBox", VB);

const el = (tag, attrs = {}, parent) => {
  const e = document.createElementNS(NS, tag);
  Object.entries(attrs).forEach(([k, v]) => e.setAttribute(k, v));
  if (parent) parent.appendChild(e);
  return e;
};

// 그림자 (좌표 단위는 지도 이미지 기준 → 값이 클수록 그림자가 큼)
const defs = el("defs", {}, popLayer);
// 글자를 흰색으로 바꾸는 필터 (RGB를 모두 1=흰색으로, 투명도는 그대로)
const whiteText = el("filter", { id: "whiteText", "color-interpolation-filters": "sRGB" }, defs);
el("feColorMatrix", { type: "matrix", values: "0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 1 0" }, whiteText);

const shadow = el("filter", { id: "popShadow", filterUnits: "userSpaceOnUse",
                              x: -200, y: -200, width: MAP_SIZE.w + 400, height: MAP_SIZE.h + 400 }, defs);
el("feDropShadow", { dx: 0, dy: 26, stdDeviation: 20, "flood-color": "#000", "flood-opacity": 0.5 }, shadow);

Object.entries(DISTRICT_PATHS).forEach(([name, d], idx) => {
  // 자치구 모양으로 지도 이미지를 오려내는 clipPath
  const clip = el("clipPath", { id: "clip" + idx }, defs);
  el("path", { d }, clip);

  // 튀어나오는 자치구 = 초록 채움 + 그 자치구만 오려낸 지도 이미지(경계선·글자 포함)
  const pop = el("g", { class: "pop", filter: "url(#popShadow)" }, popLayer);
  el("path", { d, class: "pop-fill" }, pop);
  const mkImg = (src, cls) => {
    const img = el("image", { href: src, x: 0, y: 0, width: MAP_SIZE.w, height: MAP_SIZE.h,
                              "clip-path": `url(#clip${idx})`, class: cls }, pop);
    img.setAttributeNS(XLINK, "xlink:href", src);
  };
  mkImg(LINES_SRC, "pop-lines");    // 경계선 (검정 유지)
  mkImg(LABELS_SRC, "pop-label");   // 이름 (색은 css/style.css 의 .pop-label 에서 변경)

  // 확대 기준점 = 자치구 중심
  const b = pop.querySelector(".pop-fill").getBBox();
  pop.style.transformOrigin = `${b.x + b.width / 2}px ${b.y + b.height / 2}px`;

  // 클릭/hover 영역 (크기가 변하지 않는 투명 도형 → 깜빡임 방지)
  const hit = el("path", { d, tabindex: 0, role: "link", "aria-label": name }, hitLayer);
  const on = () => {
    popLayer.appendChild(pop);      // 다른 자치구보다 맨 앞으로
    void pop.getBoundingClientRect(); // 애니메이션이 처음부터 재생되도록
    pop.classList.add("active");
  };
  const off = () => pop.classList.remove("active");
  hit.addEventListener("mouseenter", on);
  hit.addEventListener("mouseleave", off);
  hit.addEventListener("focus", on);
  hit.addEventListener("blur", off);
  const go = () => location.href = "district.html?name=" + encodeURIComponent(name);
  hit.addEventListener("click", go);
  hit.addEventListener("keydown", e => { if (e.key === "Enter") go(); });
  el("title", {}, hit).textContent = name;
});
